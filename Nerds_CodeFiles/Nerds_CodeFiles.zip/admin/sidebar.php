        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="car_detail.php" class="brand-link">

                <span class="brand-text font-weight-light">ADMIN</span>
            </a>
            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">


                        <li class="nav-item mx-3" >
                        <button class="btn btncolor btn-info text-white" style="width:200px;">
                             <a style="text-decoration:none; color:white;" href="car_detail.php" class="text-start" style="width:200px;">
                                    Car Listing                         
                            </a></button>
                        </li>
                            <li class="nav-item mt-2 mx-3">

                            <button class="btn btncolor btn-info text-white"  style="width:200px;">
                                 <a style="text-decoration:none; color:white;"  class="text-start" href="add_car.php"  style="width:200px;"> Add new cars </a>
                                </button>
                            </li>
                            <li class="nav-item mt-2 mx-3">
                            <button class="btn btncolor btn-info text-white"  style="width:200px;">
                            <a style="text-decoration:none; color:white;" href="logout.php" class="text-start"  style="width:200px;">
                                <i class="nav-icon fas fa-edit"></i>
                                    Logout
                            </a></button>

                        </li>


                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>